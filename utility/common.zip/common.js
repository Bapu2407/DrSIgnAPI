		
var moment = require('moment');

 var sendemailid='info@drsignet.com'
 var sendemailidpassword='k4dq31JQG}Q#'
 var dlog = require('debug')('dlog')
 var host = 'mail.drsignet.com'
//var host = 'smtp.gmail.com'
const Str = require('@supercharge/strings')
var nodemailer = require('nodemailer');
let htmlText,plainText=''
var fs = require('fs');

const PDFDocument = require('pdfkit');

var FONTSIZE = 9
var LABELFONTSIZE = 10





//function handleError(err,message,res,code){
    const handleError = (err,message,res,code) => {
        let errMsg
      if(code == 999){
        errMsg = err
      }else{
        errMsg = err?err.message:""
      }
    //res.status(code)
    res.status(200)
    return res.json({
        status: false,
        message: message,
        error: errMsg
      });
  
  }

  const genPDF = async (invoiceCrm) =>{
  
    let pdfURL = ''
    try{
  
    dlog(" inside gen-pdf")
  
    // Create a document
    const doc = new PDFDocument({
      bufferPages: true});;
    doc.addPage({
      margin: 5});

      doc.switchToPage(0);
      
    let fileFirstPart
  if(process.env.ENVIRONMENT =="LOCAL"){
    fileFirstPart="http://"+process.env.IPADDRESS+":"+process.env.PORT
   }else{
    fileFirstPart="http://"+process.env.IPADDRESS
   }
  
  
    let invoicPdfFilepath = "invoiceCrm"+"_"+invoiceCrm.orderId + "." + "pdf"
    
    pdfURL = fileFirstPart + "/public/pdf/" + invoicPdfFilepath

    let SECTIONGAP = 40
    let fileName = invoicPdfFilepath
    let pdfPath = process.env.PDF_FILEPATH
    doc.pipe(fs.createWriteStream(pdfPath+fileName));  
  
    let imagePath = process.env.IMAGE_PATH
    
   
   let initialX = 260
   let initialY = 50
   let firstY = initialY
   let LINELENGTH = 580
   var INVOICEHEADERFONTSIZE = 10
   var BLESSCARENAMEEHEADERFONTSIZE = 14
   var NORMALTEXTFONTSIZE = 10
   var FIRSTPOINT = 20
   var REDFONT = "#800000"
   let MOBILENUMBER = "9090111100"
   
  doc.lineWidth(0.5);
  /*doc.fillColor("black")
    .fontSize(FONTSIZE)
    .moveTo(FIRSTPOINT, initialY)
    .lineTo(LINELENGTH, initialY) 
    .stroke();*/

  

    initialY = initialY+10   
  
    /***********************************************
     
    FIRST BLOCK ABOUT BLESS HEALTHCARE 
    
    **************************************************/

   doc.font('Times-Bold')
   .fillColor(REDFONT)
   .fontSize(INVOICEHEADERFONTSIZE)
    .moveTo(70, 100)
     .text('SALES INVOICE', initialX, initialY)
     initialY = initialY+15   

  doc.font('Times-Bold')
  .fillColor(REDFONT)
  .fontSize(BLESSCARENAMEEHEADERFONTSIZE)
    .moveTo(80, 100)
     .text('BLESS HEALTHCARE', initialX-30, initialY)

     let mobileNUmberY = initialY
     initialY = initialY+25   
     
   doc.font('Times-Roman')
      .fontSize(INVOICEHEADERFONTSIZE)
      .moveTo(70, 100)
      .text("PLOT NO.190/2972, GOBINDA PRASAD, CANAL ROAD, BBSR BHUBANESHWAR-", initialX-180, initialY);
      
   
     initialY = initialY+15   
     

     doc.font('Times-Roman')
     .fillColor("black")
     .fontSize(NORMALTEXTFONTSIZE)
       .moveTo(70, 100)
        .text('Mobile No.:-'+MOBILENUMBER, initialX+170, mobileNUmberY)
   
        
        let secondLineY = initialY+15   

        doc.fillColor("black")
    .fontSize(FONTSIZE)
    .moveTo(FIRSTPOINT, secondLineY)
    .lineTo(LINELENGTH+15, secondLineY) 
    .stroke();
        

    /* END END :------ FIRST BLOCK ABOUT BLESS HEALTHCARE */

    
    



/*LEFT BORDERS AND RIGHT BORDERS */


  let firstLineInsideBoxY = secondLineY


/*END LEFT AND RIGHT BORDER */



    /***********************************************
     
    SECOND BLOCK ABOUT CUSTOMER NAME AND ADDRESS
    
    **************************************************/

   
  initialY = initialY+25   
  doc.font('Times-Bold')   
  .fontSize(BLESSCARENAMEEHEADERFONTSIZE)
    .moveTo(FIRSTPOINT+15, initialY)
     .text(invoiceCrm.customer.name,FIRSTPOINT+15 , initialY)

     let cahCardDisplayY = initialY
     initialY = initialY+15   
  doc.font('Times-Roman')   
  .fontSize(INVOICEHEADERFONTSIZE)
  
    .moveTo(FIRSTPOINT+15, initialY)
     .text("-"+invoiceCrm.customer.addressline1,FIRSTPOINT+15 , initialY)


     initialY = initialY+15   
  doc.font('Times-Roman')   
  .fontSize(INVOICEHEADERFONTSIZE)  
    .moveTo(FIRSTPOINT+15, initialY)
     .text("-"+invoiceCrm.customer.addressline2,FIRSTPOINT+15 , initialY)
     let invoiceNoDisplayY = initialY
    
    
  initialY = initialY+15   
     doc.font('Times-Roman')   
     .fontSize(INVOICEHEADERFONTSIZE)     
       .moveTo(FIRSTPOINT+15, initialY)
        .text("-"+invoiceCrm.customer.area+","+invoiceCrm.customer.po+","+invoiceCrm.customer.pin,FIRSTPOINT+15 , initialY)

       
     initialY = initialY+20  
     doc.font('Times-Roman')  
     .fontSize(INVOICEHEADERFONTSIZE)  
       .moveTo(FIRSTPOINT+15, initialY)
        .text("Phone   :"+" "+invoiceCrm.customer.mobileNumber,FIRSTPOINT+15 , initialY)
        let invoiceDateDisplayY = initialY
     initialY = initialY+20   
        doc.font('Times-Roman')   
        .fontSize(INVOICEHEADERFONTSIZE)  
          .moveTo(FIRSTPOINT+15, initialY)
           .text("State Code    :"+" "+invoiceCrm.customer.state,FIRSTPOINT+15 , initialY)
      
           initialY = initialY+20   
  let drawVerticalLINELEMGTH = initialY - firstLineInsideBoxY
   doc.lineWidth(0.5);
   //START:- DRAW VERTICAL LINE to ECLOSE CASH/CARD DISPLAY
        doc.fillColor("black")          
          .moveTo(FIRSTPOINT + 270, firstLineInsideBoxY)
          .lineTo(FIRSTPOINT + 270,initialY) 
          .stroke();
          invoiceCrm.paymentMode = 'CASH'
      if(invoiceCrm && invoiceCrm.paymentMode && invoiceCrm.paymentMode == 'COD'){
            invoiceCrm.paymentMode = 'CASH'
          }

          doc.font('Times-Bold')   
             .fontSize(BLESSCARENAMEEHEADERFONTSIZE)               
                .text(invoiceCrm.paymentMode ,FIRSTPOINT + 280, invoiceNoDisplayY)
             
    
      doc.fillColor("black")          
          .moveTo(FIRSTPOINT + 330, firstLineInsideBoxY)
          .lineTo(FIRSTPOINT + 330,initialY) 
          .stroke();
  // END :- DRAW VERTICAL LINE to ECLOSE CASH/CARD DISPLAY


    let invoiceNOX = FIRSTPOINT + 330 + 5
    doc.font('Times-Roman')   
          .fontSize(INVOICEHEADERFONTSIZE)              
             .text("Invoice No.   :",invoiceNOX, invoiceNoDisplayY)
    doc.font('Times-Bold')   
             .fontSize(BLESSCARENAMEEHEADERFONTSIZE)               
                .text(invoiceCrm._id,invoiceNOX+75, invoiceNoDisplayY)
             
     let invoiceHumanReadableDate = ''

     if(invoiceCrm.invoiceDate){
      invoiceHumanReadableDate = moment(invoiceCrm.invoiceDate).format('DD-MMM-YYYY')
     }
     doc.font('Times-Roman')   
             .fontSize(INVOICEHEADERFONTSIZE)                 
                .text("Invoice Date    :"+" "+invoiceHumanReadableDate,invoiceNOX , invoiceDateDisplayY)

    //ENDING LINE OF THE SECOND BLOCK 
    doc.fillColor("black")
    .fontSize(FONTSIZE)
    .moveTo(FIRSTPOINT, initialY)
    .lineTo(LINELENGTH+15, initialY) 
    .stroke();

    let verticalLineTopY = initialY
    //MEDICINE ROW HEADER 

    initialY = initialY+10   
    
    let verticalLineBottomY = initialY+15   
    let descriptioHeaderX = FIRSTPOINT+175
    let ROWHEADERMARGIN = 30  
    let HEADERSLEFTMARGIN = 10
    let HEADERSRIGHTMARGIN = 10
  
    drawText(doc,"Description",'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+ROWHEADERMARGIN,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175,verticalLineTopY,verticalLineBottomY)
    drawText(doc,"HSN",'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+175+15,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN,verticalLineTopY,verticalLineBottomY)
    drawText(doc,"Qty",'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSLEFTMARGIN,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN,verticalLineTopY,verticalLineBottomY)
    drawText(doc,"MRP",'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSLEFTMARGIN,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSLEFTMARGIN,verticalLineTopY,verticalLineBottomY)
    drawText(doc,"Rate",'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSLEFTMARGIN+HEADERSRIGHTMARGIN,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN,verticalLineTopY,verticalLineBottomY)
    drawText(doc,"Disc.",'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSLEFTMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN,verticalLineTopY,verticalLineBottomY)

    drawText(doc,"Total",'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSLEFTMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+HEADERSLEFTMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+20+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN,verticalLineTopY,verticalLineBottomY)

    
    drawText(doc,"CGST%",'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSLEFTMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+HEADERSLEFTMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+20,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+10,verticalLineTopY,verticalLineBottomY)

    
    drawText(doc,"SGST%",'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSLEFTMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+HEADERSLEFTMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+20+ROWHEADERMARGIN+20,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+10+ROWHEADERMARGIN+ROWHEADERMARGIN,verticalLineTopY,verticalLineBottomY)
    
    initialY = initialY+15    
    doc.fillColor("black")
    .fontSize(FONTSIZE)
    .moveTo(FIRSTPOINT, initialY)
    .lineTo(LINELENGTH+15, initialY) 
    .stroke();

    for(var i in invoiceCrm.medicineList ){
      
      let medicine = invoiceCrm.medicineList[i]
      verticalLineTopY = initialY
      verticalLineBottomY = initialY + 25
      
      initialY = initialY+15   
    drawText(doc,medicine.medicineName,'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+ROWHEADERMARGIN,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175,verticalLineTopY,verticalLineBottomY)
    drawText(doc,medicine.hsnCode,'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+175+15,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN,verticalLineTopY,verticalLineBottomY)
    drawText(doc,medicine.quantity,'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSLEFTMARGIN,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN,verticalLineTopY,verticalLineBottomY)
    drawText(doc,medicine.mrp,'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSLEFTMARGIN,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSLEFTMARGIN,verticalLineTopY,verticalLineBottomY)
    drawText(doc,medicine.mrp,'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSLEFTMARGIN+HEADERSRIGHTMARGIN,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN,verticalLineTopY,verticalLineBottomY)
    drawText(doc,medicine.discounts,'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSLEFTMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN,verticalLineTopY,verticalLineBottomY)

    drawText(doc,medicine.perProductTotal,'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSLEFTMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+HEADERSLEFTMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+20+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN,verticalLineTopY,verticalLineBottomY)

    
    drawText(doc,medicine.cGst,'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSLEFTMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+HEADERSLEFTMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+20,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+10,verticalLineTopY,verticalLineBottomY)

    
    drawText(doc,medicine.sGst,'Times-Roman',INVOICEHEADERFONTSIZE,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSLEFTMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+HEADERSLEFTMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+20+ROWHEADERMARGIN+20,initialY)      
    drawVeriticalLine(doc,FIRSTPOINT+175+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+HEADERSRIGHTMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+ROWHEADERMARGIN+10+ROWHEADERMARGIN+ROWHEADERMARGIN,verticalLineTopY,verticalLineBottomY)
    
   


    }


 doc.rect(FIRSTPOINT, firstY, LINELENGTH, initialY+100).stroke();
 


 doc.flushPages();
  doc.save()
  
  doc.end();
  
   
  return     pdfURL
        
  }catch(err){

    console.log(err)
      
    return     pdfURL
  
  }
  
  }

  const drawVeriticalLine = (doc,x,firstY,secondY) => {
    doc.fillColor("black")          
    .moveTo(x, firstY)
    .lineTo(x,secondY) 
    .stroke();
  }
  
  const drawText = (doc,text,font,fontSize,x,y,color) => {
    if(!color){
      color = "black"
    }
    doc.fillColor(color)
    .font(font)   
    .fontSize(fontSize)          
       .text(text,x , y)
  
  }

 

const sendHTMLemail = (data) => {
	new Promise((resolve, reject) => {
       
            let jsondata
            if(data.jsondata){
                jsondata = data.jsondata
            }
            var toEmail
            toEmail = data.email
            subject = data.subject           

            htmlText =  data.emailTemplate?data.emailTemplate:''  
            dlog("htmlText=="+htmlText)
            dlog("toEmail=="+toEmail)

            var transporter = nodemailer.createTransport({
            'host':host,                
            port: 587,
            'auth':{
                'user':sendemailid,
                'pass':sendemailidpassword,
                
            },     
                secure:false,    
                tls: {rejectUnauthorized: false},
                debug:true   
            });

            var sendEmail = transporter.templateSender({
                subject: subject,
                text: plainText,
                html: htmlText
            }, {
                from: sendemailid,
            });
        //  console.log("htmlText=="+htmlText)
        //  console.log("toEmail=="+toEmail)
            // use template based sender to send a message
            sendEmail({
                to: toEmail
            }, jsondata, function(err, info){

                if (err) {
                    resolve({email_sent:false})
                } //reject(err)
                else resolve({email_sent:true})
            
            });

})
}

const main =  async (uploadedFileName,inputCollection,fieldName,whichfiles) => {
    return new Promise((resolve,reject) => {
     
          if(uploadedFileName ){
            dlog("uploadedFileName :="+uploadedFileName)
  
            fs.writeFile(uploadedFileName, inputCollection[fieldName],'base64', function(err) {
              if (err) 
                
                dlog("uploadedFileName created successfully");
                reject(err)
        
            });
          }
      
          resolve("file created at desired folder")
        })
  }
  const doFileProcessing =  (inputCollection,whichfiles,uploadedFileNameSuf,fieldName,fieldNameURL)=>{
    return new Promise((resolve,reject) => {    
      let fileFirstPart; 
        if(process.env.ENVIRONMENT =="LOCAL"){
          fileFirstPart="http://"+process.env.IPADDRESS+":"+process.env.PORT
        }else{
          fileFirstPart="http://"+process.env.IPADDRESS
        }
  
        var staticImageDir = process.env.IMAGE_PATH
  /*
        const photoRandomString = Str.random(8)  
        dlog("photoRandomString ="+photoRandomString)
  
  
        let uploadedFileNameSuf = "OrderManualPrescription"+photoRandomString+"_"*/
        let uploadedFileName = staticImageDir + uploadedFileNameSuf+ "." + process.env.IMAGEFILEEXT
  
       // inputCollection.uploadedFileURL = inputCollection.fileFirstPart + "/public/images/" + uploadedFileNameSuf+ "." + process.env.IMAGEFILEEXT

       inputCollection[fieldNameURL] = fileFirstPart + "/public/images/" + uploadedFileNameSuf+ "." + process.env.IMAGEFILEEXT

        if(inputCollection[fieldName]){
          inputCollection[fieldName] = inputCollection[fieldName].replace(/^data:image\/(jpeg|png|gif|jpeg|JPG|jpg);base64,/, "");
        }   
  
  /*
        if(inputCollection.uploadedFile){
          inputCollection.uploadedFile = inputCollection.uploadedFile.replace(/^data:image\/(jpeg|png|gif|jpeg|JPG|jpg);base64,/, "");
        }   
  */
        Promise.all([createFiles(staticImageDir), main(uploadedFileName,inputCollection,fieldName,whichfiles)])
          .then(() => { resolve(inputCollection); })
          .catch((error) => { reject(error) });
          
    })
  }
  const createFiles =  (staticImageDir) => {

    return new Promise((resolve,reject) => {
      fs.stat(staticImageDir, function(err) {
        if (!err) {
            dlog('Directory exists, where the images will go');
            resolve('Directory exists, where the images will go')       
            //main(demographicFileName,inputCollection,whichfiles)
            
        }
        else if (err.code === 'ENOENT') {
            dlog('Directory does not exist where the images should be saved');
            reject(new Error('Directory does not exist, where the images will go'))
        }
      });
    });
  }
  

function convertStringTodate(dateString){
    
    var dateParts = dateString.split("-");    
    
    dlog("before 1 add dateParts[0] ="+dateParts[0])
  //  let day  = dateParts[0]++ 

   // dlog("After 1 add dateParts[0] ="+dateParts[0])
    // month is 0-based, that's why we need dataParts[1] - 1

    let utcD =   Date.UTC(dateParts[2], dateParts[1] - 1, dateParts[0],
 0, 0, 0);

    var newDate = new Date(utcD);   
   // dateParts[1] = dateParts[1] 

    //let dateStringFUll = dateParts[2]+"-"+ dateParts[1]+"-"+ dateParts[0]+"T01:00"
    //dlog("dateStringFUll ="+dateStringFUll)
    //var newDate = new Date(dateParts[2], dateParts[1] - 1, ++dateParts[0]);   
    //var newDate = new Date(dateStringFUll);   
    dlog("newDate ="+newDate.toDateString())

   // dlog("UTC day  ="+newDate.getUTCDay())
    
    return newDate
}

module.exports  = {
    sendHTMLemail:sendHTMLemail,
    handleError:handleError,
    genPDF:genPDF,
    doFileProcessing:doFileProcessing,
    convertStringTodate:convertStringTodate,
    SERVER_KEY:'AAAATSJpkA4:APA91bFV0SVGakaUAb_CmMTQP564wD_wvEPElqsE-eMvVIe3ZRaSHys-hhKHp-f6eGAZ8gIDLskMDXf30uTmPZSqOJyXtNp1QGAnMaF5_eLWfxeKnxw8sg4-nnFO5_eWocCFukaG8OXg',
    SENDER_ID:'331289825294'
}

